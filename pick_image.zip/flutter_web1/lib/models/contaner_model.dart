import 'package:flutter/material.dart';
class ContainerColor{
  static Color primaryColor=Colors.black;
  static Color textColor=Colors.yellow;
  

}